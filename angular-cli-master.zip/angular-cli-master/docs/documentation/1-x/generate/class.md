<!-- Links in /docs/documentation should NOT have `.md` at the end, because they end up in our wiki at release. -->

# ng generate class

## Overview
`ng generate class [name]` generates a class

## Options
<details>
  <summary>app</summary>
  <p>
    <code>--app</code> (aliases: <code>-a</code>) <em>default value: 1st app</em>
  </p>
  <p>
    Specifies app name to use.
  </p>
</details>

<details>
  <summary>spec</summary>
  <p>
    <code>--spec</code>
  </p>
  <p>
    Specifies if a spec file is generated.
  </p>
</details>
