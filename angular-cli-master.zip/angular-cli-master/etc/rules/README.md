# TsLint Rules

This folder contains custom TsLint rules specific to this repository.
