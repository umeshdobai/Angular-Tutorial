throw new Error(
  'In Angular CLI >6.0 the Karma plugin is now exported by "@angular-devkit/build-angular" instead.\n'
  + 'Please replace "@angular/cli" with "@angular-devkit/build-angular" in your "karma.conf.js" file.'
);
