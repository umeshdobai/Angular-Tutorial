Takes the name of the project, as specified in the  `projects` section of the `angular.json` workspace configuration file.
When a project name is not supplied, it will execute for all projects.

The default linting tool is [TSLint](https://palantir.github.io/tslint/), and the default configuration is specified in the project's `tslint.json` file.