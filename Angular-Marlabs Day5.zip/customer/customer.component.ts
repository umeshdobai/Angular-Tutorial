import { OnInit, Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Customer } from './customer';


@Component({
    selector:'cust-app',
    templateUrl:'./customer.component.html',
    styles:[`.heading{
        font-family: Broadway;
        font-size: 30px;
        color:steelblue;
    }`
    
    ]
})
export class CustomerComponent implements OnInit{
cust = new Customer();
customerForm:FormGroup;

//DI to inject form builder
constructor(private fb:FormBuilder) {

}
   ngOnInit(): void {
       this.customerForm = this.fb.group({
           firstName:'',
            lastName:'',
            email:''
       })
    }

    save(){
        console.log(this.customerForm);
        console.log('Saved data ' + JSON.stringify(this.customerForm.value) );
    }
            
}