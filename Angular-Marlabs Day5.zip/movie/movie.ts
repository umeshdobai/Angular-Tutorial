export interface IMovie{

    movieID:number;
    movieName:string;
    movieStar:string;
    movieGenre:string;
    movieRating:number;
    movieImg:string;
}