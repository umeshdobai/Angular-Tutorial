
import {Component, OnInit, OnChanges, OnDestroy} from '@angular/core';
import { IMovie } from './movie';
import { MovieService } from './movie.service';

@Component({

  selector:'mov-app', 
  templateUrl:'./movie.component.html',
  styleUrls:['./movie.component.css']
  
})

export class MovieComponent implements  OnInit{

  imgWidth:number=200;
  imgHeight:number=150;
  movTitle="Top Movies";
  showImg:boolean = false;
  movies:IMovie[]=[]; 
  searchedMovies:IMovie[]=[];
 _movieSearch:string;
 errorMessage:string;

  //Dependency Injection of Movie service
constructor(private movservice:MovieService) {
}

onRatingClicked(rate:string):void
{
this.movTitle = rate;
}

ngOnInit(): void {
  this.movservice.getMovies().subscribe(
  movies =>{
  this.movies = movies;
  this.searchedMovies = this.movies;
},
error =>this.errorMessage = error

  );
}

get movieSearch():string{
  return this._movieSearch;
}

set movieSearch(value:string)
{
  this._movieSearch = value;
  this.searchedMovies = this.movieSearch ? this.searchMovies(this.movieSearch):this.movies;
}

searchMovies(search:string):IMovie[]{

  search = search.toLocaleLowerCase();
   return this.movies.filter((movie:IMovie)=>
   movie.movieName.toLocaleLowerCase()== search);
  
}
switchImg():void{
  this.showImg = !this.showImg;
}


}


