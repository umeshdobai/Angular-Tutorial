export class User{
constructor(
public firstName = '',
public lastName = '',
public email = '',
public sendMovieMagazine = false,
public addressType = 'home',
public flatNo='',
public street2='' ,
public city='',
public state = '',
public pincode='') { }


}
    
