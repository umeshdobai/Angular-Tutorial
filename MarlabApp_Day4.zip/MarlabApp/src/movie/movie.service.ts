import { Injectable } from '@angular/core';
import { IMovie } from './movie';

@Injectable({
providedIn:'root'

})

export class MovieService{
getMovies():IMovie[]{
    return[
        {
            "movieID":1,
            "movieName":"KGF",
            "movieStar":"Yash",
            "movieGenre":"Action",
            "movieRating":1.5,
            "movieImg":"https://openclipart.org/image/800px/svg_to_png/144715/Movie-icon.png"
        },
        {
            "movieID":2,
            "movieName":"How to train your Dragon",
            "movieStar":"Dawyne",
            "movieGenre":"Animated",
            "movieRating":3.5,
            "movieImg":"https://openclipart.org/image/800px/svg_to_png/221491/Movie-Projector-Icon.png"
      
        },
        {
            "movieID":3,
            "movieName":"Inception",
            "movieStar":"Leo",
            "movieGenre":"SciFi",
            "movieRating":4.5,
            "movieImg":"https://openclipart.org/image/800px/svg_to_png/221491/Movie-Projector-Icon.png"
      
        },
        {
            "movieID":4,
            "movieName":"Moana",
            "movieStar":"Dawyne",
            "movieGenre":"Animated",
            "movieRating":5,
            "movieImg":"https://openclipart.org/image/800px/svg_to_png/221491/Movie-Projector-Icon.png"
      
        },
        {
            "movieID":5,
            "movieName":"Train to Busan",
            "movieStar":"Tim",
            "movieGenre":"Horror",
            "movieRating":3.8,
            "movieImg":"https://openclipart.org/image/800px/svg_to_png/221491/Movie-Projector-Icon.png"
      
        }
      
    ];


}


}