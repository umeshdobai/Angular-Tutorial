
import {Component, OnInit, OnChanges, OnDestroy} from '@angular/core';
import { IMovie } from './movie';
import { MovieService } from './movie.service';

@Component({

  selector:'mov-app', 
  templateUrl:'./movie.component.html'
  
})

export class MovieComponent implements  OnInit,OnChanges,OnDestroy{

  imgWidth:number=400;
  imgHeight:number=180;
  movTitle="Top Movies";

  movies:IMovie[]=[]; 


  //Dependency Injection of Movie service
constructor(private movservice:MovieService) {

}


  ngOnChanges(): void {

  console.log("At the Change detection phase!");  
  }
  ngOnDestroy(): void {
    console.log("Destroying the component");
  }

onRatingClicked(rate:string):void
{

this.movTitle = rate;

}

ngOnInit(): void {
  this.movies = this.movservice.getMovies();
}  
}