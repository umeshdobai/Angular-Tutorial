import { Input, Component, EventEmitter, Output } from '@angular/core';



@Component({
selector:'mov-rating',
templateUrl:'./rating.component.html',
styleUrls:['./rating.component.css']

})
export class MovieRating{
@Input() rating:number;
starWidth:number;
@Output() ratingClick:EventEmitter<string> =new EventEmitter<string>();

ngOnChanges():void{
    this.starWidth = +this.rating * 75/5;

}
onClick():void{
this.ratingClick.emit(`The movie rating ${this.rating} is clicked `);

}


}