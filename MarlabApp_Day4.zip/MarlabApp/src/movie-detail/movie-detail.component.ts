import { IMovie } from './../movie/movie';
import { ActivatedRoute, Router } from '@angular/router';
import { OnInit, Component } from '@angular/core';

@Component({
    templateUrl: './movie-detail.component.html',
 
})
export class MovieDetailComponent implements OnInit {

    pgtitle: string = "Movie Details";
    movie: IMovie;

    //dependency Injection 
    constructor(private route: ActivatedRoute, private router: Router) { };

    ngOnInit() {

        let id = +this.route.snapshot.paramMap.get('id');
        alert(id);
        this.pgtitle +=  `: ${id}`;
        this.movie = {
            'movieID': id,
            'movieName': 'KGF',
            'movieGenre': 'Action',
            'movieRating': 4,
            'movieImg': 'some',
            'movieStar': '5'
        };

    }

    onBack(): void {

        this.router.navigate(['/movies']);
    }

}

