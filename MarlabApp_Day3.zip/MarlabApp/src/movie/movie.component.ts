import {Component, OnInit, OnChanges, OnDestroy} from '@angular/core';
import { IMovie } from './movie';

@Component({

  selector:'mov-app', 
  templateUrl:'./movie.component.html'
  
})

export class MovieComponent implements  OnInit,OnChanges,OnDestroy{
  
constructor() {
  console.log("At constructor ");
 
}

  ngOnInit(): void {
   // this.movies. = 'Baahubali';
    //console.log("At the Init Phase! " + this.movieName);
  }

  ngOnChanges(): void {

  console.log("At the Change detection phase!");  
  }
  ngOnDestroy(): void {
    console.log("Destroying the component");
  }

  imgWidth:number=400;
  imgHeight:number=180;
  movTitle="Top Movies";

  movies:IMovie[] = [
    {
      movieID:1,
      movieName:"KGF",
      movieStar
      :"Yash",
      "movieGenre":"Action",
      "movieRating":4.5,
      "movieImg":"https://openclipart.org/image/800px/svg_to_png/144715/Movie-icon.png"
  },
  {
      "movieID":2,
      "movieName":"How to train your Dragon",
      "movieStar":"Dawyne",
      "movieGenre":"Animated",
      "movieRating":3.8,
      "movieImg":"https://openclipart.org/image/800px/svg_to_png/221491/Movie-Projector-Icon.png"

  },
  {
      "movieID":3,
      "movieName":"Inception",
      "movieStar":"Leo",
      "movieGenre":"SciFi",
      "movieRating":2.4,
      "movieImg":"https://openclipart.org/image/800px/svg_to_png/221491/Movie-Projector-Icon.png"

  },
  {
      "movieID":4,
      "movieName":"Moana",
      "movieStar":"Dawyne",
      "movieGenre":"Animated",
      "movieRating":5,
      "movieImg":"https://openclipart.org/image/800px/svg_to_png/221491/Movie-Projector-Icon.png"

  },
  {
      "movieID":5,
      "movieName":"Train to Busan",
      "movieStar":"Tim",
      "movieGenre":"Horror",
      "movieRating":3,
      "movieImg":"https://openclipart.org/image/800px/svg_to_png/221491/Movie-Projector-Icon.png"

  }


  ];

  
}