import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from 'src/Home/home.component';
import { MovieComponent } from 'src/movie/movie.component';
import { MovieDetailComponent } from 'src/movie-detail/movie-detail.component';
import { AboutComponent } from 'src/AboutUs/About.component';

const routes: Routes = [
{path:'home',component:HomeComponent},
{path:'movies',component:MovieComponent},
{path:'about',component:AboutComponent},
{path:'movies/:id',component:MovieDetailComponent},
{path:'',component:HomeComponent,pathMatch:'full'},
{path:'**',component:HomeComponent,pathMatch:'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
