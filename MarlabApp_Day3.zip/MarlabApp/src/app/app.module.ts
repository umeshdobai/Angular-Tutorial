import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MovieComponent } from '../movie/movie.component';
import {AboutComponent} from '../AboutUs/About.component';
import { TVComponent } from 'src/tvshows/tv.component';
import {FormsModule} from '@angular/forms';
import { PowerPipe } from 'src/shared/transform-spaces.pipe';
import { HomeComponent } from 'src/Home/home.component';
import { MovieDetailComponent } from 'src/movie-detail/movie-detail.component';

@NgModule({
  declarations: [
    AppComponent,
    MovieComponent,
    MovieDetailComponent,
    AboutComponent,
    HomeComponent,
    TVComponent,
    PowerPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})

export class AppModule { }
