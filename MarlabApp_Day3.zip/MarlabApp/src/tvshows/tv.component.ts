import { Component } from '@angular/core';

@Component({
    selector:'tv-show',
    templateUrl:'./tv.component.html'
})

export class TVComponent{

    showName:string='GoT';
    broadcaster:string='Netflix';
    time:number=1200;
}