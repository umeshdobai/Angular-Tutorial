import { Component } from '@angular/core';

@Component({
    selector:'abt-us',
    templateUrl:'./About.component.html',
    styleUrls:['./About.component.css']
})
export class AboutComponent{

    Title:string="Its all about Movies!";
    Contact:number=123345;
}